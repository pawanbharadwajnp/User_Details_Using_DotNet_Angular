﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using WebApiProj.Model;
using Microsoft.Extensions.Configuration;

namespace WebApiProj.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [AllowAnonymous]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly string _path;

        public UserController(IConfiguration configuration)
        {
            _configuration = configuration;
            _path = _configuration.GetValue<string>("path:link");

        }

       

        [HttpGet("")]
        public List<User> Get()
        {
            
            string filePath = _path;
            List<User> userList;

            if (System.IO.File.Exists(filePath))
            {
                string json = System.IO.File.ReadAllText(filePath);
                userList = JsonConvert.DeserializeObject<List<User>>(json);
            }
            else
            {
                userList = new List<User>();
            }

            return userList;
        }

        [HttpGet("getbyid")]
        public ActionResult<User> GetById(int id)
        {
            if (id != 0)
            {
                List<User> userList = LoadUserListFromJson();

                // Find the user with the specified ID
                User user = userList.FirstOrDefault(u => u.ID == id);
                if (user == null)
                {
                    return NotFound();
                }

                return Ok(user);
            }
            List<User> userList1 = LoadUserListFromJson();

            // Return a list of all user IDs
            //List<User> userIds = userList1.Select(u => u.ID).ToList();
           // return Ok(userIds);
           return Ok(userList1);
        }

        [HttpPost("")]
        public IActionResult InsertUser([FromBody] User user)
        {
            string filePath = _path;
            List<User> userList = new List<User>();

            if (System.IO.File.Exists(filePath))
            {
                string json = System.IO.File.ReadAllText(filePath);
                if (!string.IsNullOrEmpty(json))
                {
                    userList = JsonConvert.DeserializeObject<List<User>>(json);
                }
            }

            // Generate a new ID by incrementing the maximum existing ID
            int maxId = userList.Any() ? userList.Max(u => u.ID) : 0;
            user.ID = maxId + 1;

            userList.Add(user);
            string updatedJson = JsonConvert.SerializeObject(userList);
            System.IO.File.WriteAllText(filePath, updatedJson);

            return Ok(new StatusReply
            {
                message = "User Added Successfully",
                statusCode = "200Ok",
                Title = "Add Successful"
            });
        }



        [HttpPut("{id}")]
        public IActionResult UpdateUser(int id, [FromBody] User updatedUser)
        {
            string filePath = _path;
            List<User> userList;

            if (System.IO.File.Exists(filePath))
            {
                string json = System.IO.File.ReadAllText(filePath);
                userList = JsonConvert.DeserializeObject<List<User>>(json);

                // Find the user by ID in the list
                User userToUpdate = userList.FirstOrDefault(u => u.ID == id);
                if (userToUpdate != null)
                {
                    // Update the properties of the user
                    userToUpdate.UserName = updatedUser.UserName;
                    userToUpdate.EmailId = updatedUser.EmailId;
                    userToUpdate.Age = updatedUser.Age;
                    
                    userToUpdate.State = updatedUser.State;

                    // Serialize the updated list back to JSON
                    string updatedJson = JsonConvert.SerializeObject(userList);

                    // Write the JSON data back to the file
                    System.IO.File.WriteAllText(filePath, updatedJson);

                    return Ok(new StatusReply
                    {
                        message = "User Updated Successfully",
                        Title = "Update - Success"
                    });
                }
            }

            return Ok(new StatusReply
            {
                message = "User Updated Failed",
                Title = "Update = Failed"
            });
        }

        private List<User> LoadUserListFromJson()
        {
            List<User> userList = new List<User>();

            if (System.IO.File.Exists(_path))
            {
                string json = System.IO.File.ReadAllText(_path);
                if (!string.IsNullOrEmpty(json))
                {
                    userList = JsonConvert.DeserializeObject<List<User>>(json);
                }
            }

            return userList;
        }



    }
}
