﻿namespace WebApiProj.Model
{
    public class StatusReply
    {
        public string message { get; set; }

        public string statusCode { get; set; }

        public string Title { get; set; }
    }
}
