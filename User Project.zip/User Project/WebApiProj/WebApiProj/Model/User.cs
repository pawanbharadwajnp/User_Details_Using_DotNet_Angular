﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace WebApiProj.Model
{
    public class User
    {
        [JsonProperty("id")]
        
        public int ID { get; set; }

        [JsonProperty("userName")]
        
        public string UserName { get; set; }

        [JsonProperty("emailId")]
        
        public string EmailId { get; set; }

        [JsonProperty("age")]
        public string Age { get; set; }

/*        [JsonProperty("createdAt")]
        public DateTime CreatedAt { get; set; }

        [JsonProperty("updatedAt")]
        public DateTime UpdatedAt { get; set; }
*/
        [JsonProperty("state")]
        public string State { get; set; }
    }
}
