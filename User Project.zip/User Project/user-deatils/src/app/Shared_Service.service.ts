import { Injectable } from "@angular/core";
import { User } from "./Users";

@Injectable()
export class service {
  private user: User | undefined;

  public setUser(user: User) {
    this.user = user;
  }

  public getUser() {
    const user = this.user;
    this.user = undefined; // Reset the value to undefined
    return user;  }
}
