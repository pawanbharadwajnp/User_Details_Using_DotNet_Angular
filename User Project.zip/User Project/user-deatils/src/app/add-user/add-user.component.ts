import { Component, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../Users';

import { service } from '../Shared_Service.service';


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent {
  @Output() updateCondition = new EventEmitter<boolean>();
  update: boolean = false;
  public userName: string = '';
  public Email: string = '';
  public age: string = '';
  public state: string = '';


  constructor(private http: HttpClient, private _service : service) { }

  
  ngOnInit() {
    let user: User | undefined = this._service.getUser();
     if(user != null) {
      const inputElement = document.getElementById("userName") as HTMLInputElement | null;
  
      if (inputElement) {
        this.userName = user.userName;
        this.Email = user.emailId;
        this.age = user.age
        this.state = user.state;
      }    
    }



  }
  


  Back() {
    this.updateCondition.emit(true);
  }

  addUser(user: User): Observable<User> {
    const url = 'https://localhost:5001/User/';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json' // Set the Content-Type header to application/json
      })
    };
    return this.http.post<User>(url, user, httpOptions);
  }


  UpdateUser(user: User): Observable<User> {
    const url = 'https://localhost:5001/User/' + user.id;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json' // Set the Content-Type header to application/json
      })
    };
    return this.http.put<User>(url, user, httpOptions);
  }

  onSubmit(form: any) {

   

    if (this._service.getUser() != null) {
      // _user has emitted a value, use it
      const _user: User | undefined = this._service.getUser();
     if(_user != null){
      
      const nameElement: HTMLInputElement = <HTMLInputElement>document.getElementById("userName");
      const name: string = nameElement.value;
      
      const emailElement: HTMLInputElement = <HTMLInputElement>document.getElementById("emailId");
      const email: string = emailElement.value;
      
      const ageElement: HTMLInputElement = <HTMLInputElement>document.getElementById("age");
      const age: string = ageElement.value;

      const stateElement: HTMLInputElement = <HTMLInputElement>document.getElementById("state");
      const state: string = stateElement.value;

      const user: User = {
        id: _user.id,
        userName: name,
        emailId: email,
        age: age,
        state: state
      };

      this.UpdateUser(user).subscribe(
        () => {
          console.log('User Updated successfully.');
          // Additional logic after successful user addition
          this.Back();
        },
        (error) => {
          console.error('Failed to add user:', error);
          // Additional error handling logic
        }
      );

    }
 
    } else {
      const nameElement: HTMLInputElement = <HTMLInputElement>document.getElementById("userName");
      const name: string = nameElement.value;
      
      const emailElement: HTMLInputElement = <HTMLInputElement>document.getElementById("emailId");
      const email: string = emailElement.value;
      
      const ageElement: HTMLInputElement = <HTMLInputElement>document.getElementById("age");
      const age: string = ageElement.value;

      const stateElement: HTMLInputElement = <HTMLInputElement>document.getElementById("state");
      const state: string = stateElement.value;

      const user: User = {
        id: 0,
        userName: name,
        emailId: email,
        age: age,
        state: state
      };

      console.log(user);

      this.addUser(user).subscribe(
        () => {
          console.log('User added successfully.');
          // Additional logic after successful user addition
          this.Back();
        },
        (error) => {
          console.error('Failed to add user:', error);
          // Additional error handling logic
        }
      );
    }
  }
}
