export class User {
    constructor(
      public id: number,
      public userName: string,
      public emailId: string,
      public age: string,
      public state: string
    ) {}
  }
  