import { Component, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../Users';
import { service } from '../Shared_Service.service';


@Component({
  selector: 'app-component-name',
  templateUrl: './component-name.component.html',
  styleUrls: ['./component-name.component.css']
})
export class ComponentNameComponent {
  @Output() updateCondition = new EventEmitter<boolean>();

  userList: User[] = [];

  constructor(private http: HttpClient, private _service : service  ) { }

  addUser() {
    this.updateCondition.emit(false);
  }

  // UpdateUser(user : User) {
  //   this._service.setUser(user);
  //    this.updateCondition.emit(false);
     
  // }

  UpdateUser(user: User) {
    this._service.setUser(user);
    this.updateCondition.emit(false);
    // Prefill the form with the user data
    this.userList.push(user); // Assuming you have a variable named 'user' in your component to bind to the form fields
  }
  

  getUserList(): Observable<User[]> {
    const url = 'https://localhost:5001/User/';
    return this.http.get<User[]>(url);
  }

  ngOnInit() {
    this.getUserList().subscribe(
      (response) => {
        // Handle the response data (list of users)
        this.userList = response;
        console.log(response);
      },
      (error) => {
        // Handle any errors
        console.error(error);
      }
    );
  }
}
