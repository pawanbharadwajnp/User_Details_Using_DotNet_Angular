import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ComponentNameComponent } from './component-name/component-name.component';
import { AddUserComponent } from './add-user/add-user.component';
import { service } from './Shared_Service.service';

@NgModule({
  declarations: [
    AppComponent,
    ComponentNameComponent,
    AddUserComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [service],
  bootstrap: [AppComponent]
})
export class AppModule { }
